# Figures

Place final manuscript figures or reproducible figure outputs here if approved by the corresponding author.

Suggested structure:

```text
figures/
├── final/
└── generated/
```

Generated figures can be excluded from Git if they are reproducible from scripts and large output files.
