# Results

Place small, non-identifiable derived results tables here if needed for reproducibility. Large intermediate objects should be archived separately or regenerated from the source data.

Examples:

- Differential expression result tables
- Signature score summary tables
- Survival model outputs
- Cell type annotation marker summaries
