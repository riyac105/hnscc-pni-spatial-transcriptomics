# Data

Raw public datasets are not included in this repository. Download raw data from the original repositories using the following accessions:

- GSE300147: Xenium HNSCC spatial transcriptomics
- GSE281978: Visium HNSCC spatial transcriptomics
- GSE181300: Visium invasive front HNSCC spatial transcriptomics
- TCGA-HNSC PanCancer Atlas 2018: bulk transcriptomic and clinical validation via cBioPortal
- GSE65858: independent bulk transcriptomic validation cohort

Suggested local directory structure:

```text
data/
├── raw/
│   ├── GSE300147/
│   ├── GSE281978/
│   ├── GSE181300/
│   ├── TCGA_HNSC/
│   └── GSE65858/
└── processed/
```

Large raw or processed data files should generally not be committed to GitHub. If derived data objects are needed for reproducibility and are small enough to share, place them in a public archive or release asset and describe them here.
